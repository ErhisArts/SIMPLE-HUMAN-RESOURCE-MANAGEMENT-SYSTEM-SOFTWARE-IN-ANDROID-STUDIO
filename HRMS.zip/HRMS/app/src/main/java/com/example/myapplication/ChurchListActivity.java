package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class ChurchListActivity extends AppCompatActivity {
    ListView memberLV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_churchlist);

        memberLV = findViewById(R.id.memberListLV);

        ArrayList<Member> memberList = Member.getMemberList();

        MemberListAdapter adapter = new MemberListAdapter(this, memberList);

       memberLV.setAdapter(adapter);

        memberLV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Member member = Member.getMemberList().get(position);
                Intent intent = new Intent(ChurchListActivity.this, MemberDetailsActivity.class);
                intent.putExtra("Member", member);
                startActivity(intent);


            }
        });


    }

    public void addMember(View view) {
        Intent intent = new Intent(this, AddMemberActivity.class);
        startActivity(intent);
    }
}
