package com.example.myapplication;

public class ClassItem {
    private long cid;

    public ClassItem(long cid, String className, String classTeacher, String classSubject, String classTerm) {
        this.cid = cid;
        ClassName = className;
        ClassTeacher = classTeacher;
        ClassSubject = classSubject;
        ClassTerm = classTerm;
    }

    private String ClassName;
    private String ClassTeacher;
    private String ClassSubject;
    private String ClassTerm;

    public String getClassName() {
        return ClassName;
    }

    public void setClassName(String className) {
        ClassName = className;
    }

    public String getClassTeacher() {
        return ClassTeacher;
    }

    public void setClassTeacher(String classTeacher) {
        ClassTeacher = classTeacher;
    }

    public String getClassSubject() {
        return ClassSubject;
    }

    public void setClassSubject(String classSubject) {
        ClassSubject = classSubject;
    }

    public String getClassTerm() {
        return ClassTerm;
    }

    public void setClassTerm(String classTerm) {
        ClassTerm = classTerm;
    }

    public ClassItem(String className, String classTeacher, String classSubject, String classTerm) {
        this.ClassName = className;
        this.ClassTeacher = classTeacher;
        this.ClassSubject = classSubject;
        this.ClassTerm = classTerm;
    }

    public long getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }
}
