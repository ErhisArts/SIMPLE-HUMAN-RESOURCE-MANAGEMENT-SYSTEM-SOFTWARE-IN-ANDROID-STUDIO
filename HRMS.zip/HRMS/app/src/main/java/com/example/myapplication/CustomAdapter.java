package com.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    private Context context;
    Activity activity;
    private ArrayList book_id, book_name, book_position, book_email, book_dob, book_quality;
    CustomAdapter(Activity activity,
                  Context context,
                  ArrayList book_id,
                  ArrayList book_name,
                  ArrayList book_position,
                  ArrayList book_email,
                  ArrayList book_dob,
                  ArrayList book_quality){
        this.activity = activity;
        this.context = context;
        this.book_id = book_id;
        this.book_name = book_name;
        this.book_position = book_position;
        this.book_email = book_email;
        this.book_dob = book_dob;
        this.book_quality = book_quality;

    }

    @NonNull
    @Override
    public CustomAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
       View view = inflater.inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter.MyViewHolder holder, int position) {
        holder.book_id_txt.setText(String.valueOf(book_id.get(position)));
        holder.book_name_txt.setText(String.valueOf(book_name.get(position)));
        holder.book_position_txt.setText(String.valueOf(book_position.get(position)));
        holder.book_email_txt.setText(String.valueOf(book_email.get(position)));
        holder.book_dob_txt.setText(String.valueOf(book_dob.get(position)));
        holder.book_quality_txt.setText(String.valueOf(book_quality.get(position)));
        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, MainActivity2.class);
                intent.putExtra("id", String.valueOf(book_id.get(position)));
                intent.putExtra("name", String.valueOf(book_name.get(position)));
                intent.putExtra("position", String.valueOf(book_position.get(position)));
                intent.putExtra("email", String.valueOf(book_email.get(position)));
                intent.putExtra("dob", String.valueOf(book_dob.get(position)));
                intent.putExtra("quality", String.valueOf(book_quality.get(position)));
               activity.startActivityForResult(intent, 1);
            }
        });

    }

    @Override
    public int getItemCount() {
        return book_id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView book_id_txt, book_name_txt, book_position_txt, book_email_txt, book_dob_txt, book_quality_txt;
        ConstraintLayout mainLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            book_id_txt = itemView.findViewById(R.id.book_id_txt);
            book_name_txt = itemView.findViewById(R.id.book_name_txt);
            book_position_txt = itemView.findViewById(R.id.book_position_txt);
            book_email_txt = itemView.findViewById(R.id.book_email_txt);
            book_dob_txt = itemView.findViewById(R.id.book_dob_txt);
            book_quality_txt = itemView.findViewById(R.id.book_quality_txt);
            mainLayout = itemView.findViewById(R.id.mainLayout);
        }
    }
}
