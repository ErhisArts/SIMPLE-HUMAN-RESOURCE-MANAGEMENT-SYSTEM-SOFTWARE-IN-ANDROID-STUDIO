package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText _username,_password,_password1;
    Button _button1;
    TextView _textView2;
    Backgroundtask DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        _button1=(Button)findViewById(R.id.button2);
        _username=(EditText)findViewById(R.id.usernames);
        _password=(EditText)findViewById(R.id.passwords);
        _textView2=(TextView)findViewById(R.id.textView3);
        DB = new Backgroundtask(this);
        _button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = _username.getText().toString();
                String pass = _password.getText().toString();

                if(user.equals("")||pass.equals(""))
                    Toast.makeText(LoginActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                else{
                    Boolean checkuserpass = DB.checkusernamepassword(user, pass);
                    if(checkuserpass==true){
                        Toast.makeText(LoginActivity.this, "Signed in successfully", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(LoginActivity.this, "Invalid Login details", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        _textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), signup.class);
                startActivity(intent);
            }
        });
    }
}