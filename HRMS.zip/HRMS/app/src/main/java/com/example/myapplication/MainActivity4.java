package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;


import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity4 extends AppCompatActivity {

    FloatingActionButton fab;
    RecyclerView recycler;
    ClassAdapter classAdapter;
    RecyclerView.LayoutManager layoutManager;
    ArrayList<ClassItem> classItems = new ArrayList<>();
    Toolbar toolbar;
    DbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        dbHelper = new DbHelper(this);

        fab = findViewById(R.id.fab_main);
        fab.setOnClickListener(v -> showDialog());

        loadData();

        recycler = findViewById(R.id.recycler);
        recycler.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recycler.setLayoutManager(layoutManager);
       classAdapter = new ClassAdapter(this, classItems);
        recycler.setAdapter(classAdapter);
        classAdapter.setOnItemClickListener(position -> gotoItemActivity(position));

        setToolbar();
    }

    private void loadData() {
        Cursor cursor = dbHelper.getClassTable();

        classItems.clear();;
        while (cursor.moveToNext()){
            int id= cursor.getInt(cursor.getColumnIndex(DbHelper.C_ID));
            String className = cursor.getString(cursor.getColumnIndex(DbHelper.CLASS_NAME_KEY));
            String classTeacher = cursor.getString(cursor.getColumnIndex(DbHelper.CLASS_TEACHER_KEY));
            String classSubject = cursor.getString(cursor.getColumnIndex(DbHelper.SUBJECT_NAME_KEY));
            String classTerm = cursor.getString(cursor.getColumnIndex(DbHelper.CLASS_TERM_KEY));

            classItems.add(new ClassItem(id, className, classTeacher, classSubject, classTerm));

        }


    }

    private void setToolbar() {
        toolbar = findViewById(R.id.toolbar);
        TextView title = toolbar.findViewById(R.id.title_toolbar);
        TextView subtitle1 = toolbar.findViewById(R.id.subtitle_toolbar1);
        TextView subtitle =toolbar.findViewById(R.id.subtitle_toolbar);
        ImageButton back = toolbar.findViewById(R.id.back);
        ImageButton save = toolbar.findViewById(R.id.imagess);

        title.setText("Attendance");
        subtitle.setVisibility(View.GONE);
        subtitle1.setVisibility(View.GONE);
        back.setVisibility(View.INVISIBLE);
        save.setVisibility(View.INVISIBLE);
    }

    private void gotoItemActivity(int position) {
        Intent intent = new Intent(this,StudentActivity.class);
        intent.putExtra("className",classItems.get(position).getClassName());
        intent.putExtra("classTeacher",classItems.get(position).getClassTeacher());
        intent.putExtra("classSubject",classItems.get(position).getClassSubject());
        intent.putExtra("classTerm",classItems.get(position).getClassTerm());
        intent.putExtra("position", position);
        intent.putExtra("cid", classItems.get(position).getCid());
        startActivity(intent);
    }

    private void showDialog() {
            MyDialog dialog = new MyDialog();
            dialog.show(getSupportFragmentManager(), MyDialog.CLASS_ADD_DIALOG);
            dialog.setListener((className, classTeacher, classSubject, classTerm)->addclass(className,
                    classTeacher, classSubject, classTerm));
    }

    private void addclass(String className, String classTeacher, String classSubject, String classTerm) {
        long cid = dbHelper.addBook(className, classTeacher, classSubject, classTerm);
        ClassItem classItem = new ClassItem(cid, className, classTeacher, classSubject, classTerm);
        classItems.add(classItem);
        classAdapter.notifyDataSetChanged();

    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case 0:
                showUpdateDialog(item.getGroupId());
                break;
            case 1:
                deleteClass(item.getGroupId());

        }
        return super.onContextItemSelected(item);
    }

    private void showUpdateDialog(int position) {
        MyDialog dialog = new MyDialog();
        dialog.show(getSupportFragmentManager(),MyDialog.CLASS_UPDATE_DIALOG);
        dialog.setListener((className, classTeacher, classSubject, classTerm)->updateClass(position,className, classTeacher, classSubject, classTerm));
    }

    private void updateClass(int position, String className, String classTeacher, String classSubject, String classTerm) {
        dbHelper.UpdateBook(classItems.get(position).getCid(),className,classSubject,classTeacher,classTerm);
        classItems.get(position).setClassName(className);
        classItems.get(position).setClassTeacher(classTeacher);
        classItems.get(position).setClassSubject(classSubject);
        classItems.get(position).setClassTerm(classTerm);
        classAdapter.notifyItemChanged(position);
    }

    private void deleteClass(int position) {
        dbHelper.deleteClass(classItems.get(position).getCid());
        classItems.remove(position);
        classAdapter.notifyItemRemoved(position);
    }
}