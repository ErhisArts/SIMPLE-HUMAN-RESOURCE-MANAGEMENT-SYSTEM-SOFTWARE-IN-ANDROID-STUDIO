package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity5 extends AppCompatActivity {

    RecyclerView recycle;
    PaymentAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        recycle = findViewById(R.id.recycle);

        setRecyclerView();
    }

    private void setRecyclerView() {
        recycle.setHasFixedSize(true);
        recycle.setLayoutManager(new LinearLayoutManager(this));
        adapter = new PaymentAdapter(this,getList());
        recycle.setAdapter(adapter);
    }

    private List<PaymentMode> getList(){
        List<PaymentMode> payment_list = new ArrayList<>();
        payment_list.add(new PaymentMode("HeadMistress","40000","1500","38500"));
        payment_list.add(new PaymentMode("Secretary","35000","1500","33500"));
        payment_list.add(new PaymentMode("Class 6 Teacher","35000","1500","33500"));
        payment_list.add(new PaymentMode("Class 5 Teacher","35000","1500","33500"));
        payment_list.add(new PaymentMode("Class 4 Teacher","35000","1500","33500"));
        payment_list.add(new PaymentMode("Class 3 Teacher","35000","1500","33500"));
        payment_list.add(new PaymentMode("Class 2 Teacher","35000","1500","33500"));
        payment_list.add(new PaymentMode("Class 1 Teacher","35000","1500","33500"));
        payment_list.add(new PaymentMode("Prep 2 Teacher","35000","1500","33500"));
        payment_list.add(new PaymentMode("Prep 1 Teacher","35000","1500","33500"));
        payment_list.add(new PaymentMode("Creche 2 Teacher","35000","1500","33500"));
        payment_list.add(new PaymentMode("Creche 1 Teacher","35000","1500","33500"));
        payment_list.add(new PaymentMode("Cleaner","35000","1500","33500"));
        return payment_list;
    }
}