package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity6 extends AppCompatActivity {

    RecyclerView recycle;
    PaymentAdapter1 adapter1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        recycle = findViewById(R.id.recycle);

        setRecycleView();


    }

    private void setRecycleView() {
        recycle.setHasFixedSize(true);
        recycle.setLayoutManager(new LinearLayoutManager(this));
        adapter1 = new PaymentAdapter1(this,getList());
        recycle.setAdapter(adapter1);
    }

    private List<PaymentMode1> getList(){
        List<PaymentMode1> payment_list = new ArrayList<>();
        payment_list.add(new PaymentMode1("New Year", "1st January 2021"));
        payment_list.add(new PaymentMode1("Staff Resumption", "11th January 2021"));
        payment_list.add(new PaymentMode1("Student Resumption", "18th January 2021"));
        payment_list.add(new PaymentMode1("Valentine Day", "14th February 2021"));
        payment_list.add(new PaymentMode1("Open day", "20th February 2021"));
        payment_list.add(new PaymentMode1("PTA Meeting", "25th February 2021"));
        payment_list.add(new PaymentMode1("Excursion", "27th February 2021"));
        payment_list.add(new PaymentMode1("Open day", "20th February 2021"));
        return payment_list;
    }
}