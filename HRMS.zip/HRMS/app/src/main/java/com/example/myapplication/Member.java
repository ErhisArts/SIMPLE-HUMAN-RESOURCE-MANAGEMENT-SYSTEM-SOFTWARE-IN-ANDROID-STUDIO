package com.example.myapplication;

import java.io.Serializable;
import java.util.ArrayList;

public class Member implements Serializable {
    private String name, phone, email, dob, division, gender;

    ArrayList<String> skillList = new ArrayList<String>();

    private static ArrayList<Member> memberList = new ArrayList<Member>();


    public Member(String name, String phone, String email, String dob, String division, String gender, ArrayList<String> skillList) {
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.dob = dob;
        this.division = division;
        this.gender = gender;
        this.skillList = skillList;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getDob() {
        return dob;
    }

    public String getDivision() {
        return division;
    }

    public String getGender() {
        return gender;
    }

    public ArrayList<String> getSkillList() {
        return skillList;
    }

    public static void addMemberIntheList(Member member){
        memberList.add(member);
    }

    public static ArrayList<Member> getMemberList() {
        return memberList;
    }
}
