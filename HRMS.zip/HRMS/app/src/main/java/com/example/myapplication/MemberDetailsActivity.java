package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;

public class MemberDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_member_details);

        Intent intent = getIntent();
        Member member = (Member) intent.getSerializableExtra("member");

        Log.d("name", member.getName());
        Log.d("phone", member.getPhone());
        Log.d("email", member.getEmail());
        Log.d("dob", member.getDob());
        Log.d("division", member.getDivision());
        Log.d("gender", member.getGender());


    }
}