package com.example.myapplication;

import android.content.Context;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class MemberListAdapter extends ArrayAdapter {
    private ArrayList<Member> memberList;
    private Context context;

    public MemberListAdapter(@NonNull Context context, ArrayList<Member> memberList) {
        super(context, R.layout.member_list_adapter, memberList);

        this.memberList = memberList;
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.member_list_adapter, parent, false);

        TextView nameTV = convertView.findViewById(R.id.nameTV);
        TextView emailTV = convertView.findViewById(R.id.emailTV);

        nameTV.setText(memberList.get(position).getName());
        emailTV.setText(memberList.get(position).getEmail());

        return convertView;
    }
}