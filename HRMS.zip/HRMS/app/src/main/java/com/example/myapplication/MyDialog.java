package com.example.myapplication;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

public class MyDialog extends DialogFragment {

   public static final String STUDENT_ADD_DIALOG="addStudent";
    public static final String CLASS_UPDATE_DIALOG="updateClass";
    public static final String CLASS_ADD_DIALOG="addClass";
    public static final String STUDENT_UPDATE_DIALOG = "updateStudent" ;

    private OnClickListener listener;
    private int roll;
    private String names;

    public MyDialog(int roll, String names) {

        this.roll = roll;
        this.names = names;
    }

    public MyDialog() {

    }

    public interface OnClickListener{
       void onClick(String text1, String text2, String text3, String text4);
   }

    public void setListener(OnClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Dialog dialog = null;
        if (getTag().equals(CLASS_ADD_DIALOG))dialog=getAddClassDialog();
        if (getTag().equals(STUDENT_ADD_DIALOG))dialog = getAddStudentDialog();
        if (getTag().equals(CLASS_UPDATE_DIALOG))dialog = getUpdateClassDialog();
        if (getTag().equals(STUDENT_UPDATE_DIALOG))dialog = getUpdateStudentDialog();
        return dialog;
    }

    private Dialog getUpdateStudentDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.class_dialog1, null);
        builder.setView(view);

        TextView title =view.findViewById(R.id.titleDialogue);
        title.setText("Update Student");

        EditText roll_name1 = view.findViewById(R.id.class_name);
        EditText names_teacher1 = view.findViewById(R.id.class_teacher);
        EditText class_subject1 = view.findViewById(R.id.class_subject);
        EditText class_term1 = view.findViewById(R.id.class_term);


        roll_name1.setHint("Roll, numbers only");
        names_teacher1.setHint("Name");
        class_subject1.setHint("Add Subject");
        class_term1.setHint("Term");
        Button cancel_btn =  view.findViewById(R.id.cancel_btn);
        Button add_btn =  view.findViewById(R.id.add_btn);
        add_btn.setText("Update");
        roll_name1.setText(roll+"");
        roll_name1.setEnabled(false);
        names_teacher1.setText(names);
        cancel_btn.setOnClickListener(v ->  dismiss());
        add_btn.setOnClickListener(v -> {
            String roll = roll_name1.getText().toString();
            String names = names_teacher1.getText().toString();
            String classSubject = class_subject1.getText().toString();
            String classTerm = class_term1.getText().toString();
            listener.onClick(roll, names, classSubject, classTerm);
            dismiss();
        });
        return  builder.create();
    }

    private Dialog getUpdateClassDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.class_dialog, null);
        builder.setView(view);

        TextView title =view.findViewById(R.id.titleDialogue);
        title.setText("Update Attendance");

        EditText class_name1 = view.findViewById(R.id.class_name);
        EditText class_teacher1 = view.findViewById(R.id.class_teacher);
        EditText class_subject1 = view.findViewById(R.id.class_subject);
        EditText class_term1 = view.findViewById(R.id.class_term);

        class_name1.setHint("Class Name");
        class_teacher1.setHint("Teacher name");
        class_subject1.setHint("Add Subject");
        class_term1.setHint("Term");
        Button cancel_btn =  view.findViewById(R.id.cancel_btn);
        Button add_btn =  view.findViewById(R.id.add_btn);
        add_btn.setText("update");

        cancel_btn.setOnClickListener(v ->  dismiss());
        add_btn.setOnClickListener(v -> {
            String className = class_name1.getText().toString();
            String classTeacher = class_teacher1.getText().toString();
            String classSubject = class_subject1.getText().toString();
            String classTerm = class_term1.getText().toString();
            listener.onClick(className, classTeacher, classSubject, classTerm);
            dismiss();
        });
        return  builder.create();
    }

    private Dialog getAddStudentDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.class_dialog1, null);
        builder.setView(view);

        TextView title =view.findViewById(R.id.titleDialogue);
        title.setText("Add new Student");

        EditText roll_name1 = view.findViewById(R.id.class_name);
        EditText names_teacher1 = view.findViewById(R.id.class_teacher);
        EditText class_subject1 = view.findViewById(R.id.class_subject);
        EditText class_term1 = view.findViewById(R.id.class_term);


        roll_name1.setHint("Roll, numbers only");
        names_teacher1.setHint("Name");
        class_subject1.setHint("Add Subject");
        class_term1.setHint("Term");
        Button cancel_btn =  view.findViewById(R.id.cancel_btn);
        Button add_btn =  view.findViewById(R.id.add_btn);

        cancel_btn.setOnClickListener(v ->  dismiss());
        add_btn.setOnClickListener(v -> {
            String roll = roll_name1.getText().toString();
            String names = names_teacher1.getText().toString();
            String classSubject = class_subject1.getText().toString();
            String classTerm = class_term1.getText().toString();
            roll_name1.setText(String.valueOf(Integer.parseInt(roll)+1));
            listener.onClick(roll, names, classSubject, classTerm);
            dismiss();
        });
        return  builder.create();

    }

    private Dialog getAddClassDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.class_dialog, null);
        builder.setView(view);

        TextView title =view.findViewById(R.id.titleDialogue);
        title.setText("Add new Attendance");

        EditText class_name1 = view.findViewById(R.id.class_name);
        EditText class_teacher1 = view.findViewById(R.id.class_teacher);
        EditText class_subject1 = view.findViewById(R.id.class_subject);
        EditText class_term1 = view.findViewById(R.id.class_term);

        class_name1.setHint("Class Name");
        class_teacher1.setHint("Teacher name");
        class_subject1.setHint("Add Subject");
        class_term1.setHint("Term");
        Button cancel_btn =  view.findViewById(R.id.cancel_btn);
        Button add_btn =  view.findViewById(R.id.add_btn);

        cancel_btn.setOnClickListener(v ->  dismiss());
        add_btn.setOnClickListener(v -> {
                String className = class_name1.getText().toString();
                String classTeacher = class_teacher1.getText().toString();
                String classSubject = class_subject1.getText().toString();
                String classTerm = class_term1.getText().toString();
                listener.onClick(className, classTeacher, classSubject, classTerm);
                dismiss();
        });
        return  builder.create();
    }
}
