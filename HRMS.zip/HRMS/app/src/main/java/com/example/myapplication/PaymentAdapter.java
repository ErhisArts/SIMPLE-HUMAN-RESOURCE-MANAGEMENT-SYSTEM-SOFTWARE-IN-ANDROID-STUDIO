package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.List;

public class PaymentAdapter extends RecyclerView.Adapter<PaymentAdapter.ViewHolder> {

    Context context;
    List<PaymentMode>payment_list;

    public PaymentAdapter(Context context,List<PaymentMode> payment_list) {
        this.context = context;
        this.payment_list = payment_list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_layout,parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if(payment_list != null && payment_list.size() > 0 ){
            PaymentMode mode = payment_list.get(position);
            holder.position_tv.setText(mode.getPosition());
            holder.salary_tv.setText(mode.getSalary());
            holder.tax_tv.setText(mode.getTax());
            holder.income_tv.setText(mode.getIncome());
        }else {
            return;
        }

    }

    @Override
    public int getItemCount() {
        return payment_list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView position_tv,salary_tv,tax_tv,income_tv;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            position_tv = itemView.findViewById(R.id.position_tv);
            salary_tv = itemView.findViewById(R.id.salary_tv);
            tax_tv = itemView.findViewById(R.id.tax_tv);
            income_tv = itemView.findViewById(R.id.income_tv);

        }
    }
}
