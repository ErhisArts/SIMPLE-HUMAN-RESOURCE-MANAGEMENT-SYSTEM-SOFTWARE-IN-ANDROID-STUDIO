package com.example.myapplication;



import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class PaymentAdapter1 extends RecyclerView.Adapter<PaymentAdapter1.ViewHolder> {


    Context context;
    List<PaymentMode1> payment_list;

    public PaymentAdapter1(Context context, List<PaymentMode1> payment_list) {
        this.context = context;
        this.payment_list = payment_list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_layout1,parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (payment_list != null && payment_list.size() > 0){
            PaymentMode1 mode1 = payment_list.get(position);
            holder.position_tv.setText(mode1.getPosition1());
            holder.salary_tv.setText(mode1.getSalary1());
        }else {
            return;
        }

    }

    @Override
    public int getItemCount() {
        return payment_list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView position_tv, salary_tv;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            position_tv = itemView.findViewById(R.id.position_tv1);
            salary_tv = itemView.findViewById(R.id.salary_tv1);
        }
    }
}
