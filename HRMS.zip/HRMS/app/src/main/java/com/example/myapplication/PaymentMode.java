package com.example.myapplication;

public class PaymentMode {
    String position;
    String salary;
    String tax;
    String income;

    public PaymentMode(String position, String salary, String tax, String income) {
        this.position = position;
        this.salary = salary;
        this.tax = tax;
        this.income = income;
    }
    public String getPosition() {
        return position;
    }

    public String getSalary() {
        return salary;
    }

    public String getTax() {
        return tax;
    }

    public String getIncome() {
        return income;
    }
}
