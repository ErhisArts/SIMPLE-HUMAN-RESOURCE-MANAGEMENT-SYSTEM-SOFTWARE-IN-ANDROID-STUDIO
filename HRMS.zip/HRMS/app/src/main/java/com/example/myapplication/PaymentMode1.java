package com.example.myapplication;

public class PaymentMode1 {
    String position1;
    String salary1;

    public PaymentMode1(String position1, String salary1) {
        this.position1 = position1;
        this.salary1 = salary1;
    }

    public String getPosition1() {
        return position1;
    }

    public String getSalary1() {
        return salary1;
    }
}
