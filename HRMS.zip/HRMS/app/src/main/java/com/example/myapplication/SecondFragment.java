package com.example.myapplication;

import androidx.fragment.app.Fragment;

public class SecondFragment extends Fragment {

}