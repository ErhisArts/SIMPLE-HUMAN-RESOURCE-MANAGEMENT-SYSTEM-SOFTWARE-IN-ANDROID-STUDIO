package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class signup extends AppCompatActivity {

     public static final String EXTRA_TEXT = "com.example.application.example.EXTRA_TEXT";

    EditText _username,_password,_password1,_password2;
    Button  _button1;
    TextView _textView2;
    Backgroundtask DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        _button1=(Button)findViewById(R.id.button1);
        _username=(EditText)findViewById(R.id.username);
        _password=(EditText)findViewById(R.id.password);
        _password1=(EditText)findViewById(R.id.password1);
        _password2=(EditText)findViewById(R.id.password2);
        _textView2=(TextView)findViewById(R.id.textView2);
        DB = new Backgroundtask(this);
        _button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             String user = _username.getText().toString();
             String pass = _password.getText().toString();
             String repass = _password1.getText().toString();
             String passcode = _password2.getText().toString();

             if(user.equals("")||pass.equals("")||repass.equals("")||passcode.equals(""))
                 Toast.makeText(signup.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
             else {
                 if(pass.equals(repass)){
                     Boolean checkuser = DB.checkusername(user);
                     if(checkuser==false){
                         Boolean insert = DB.insertData(user, pass);
                         if(insert==true||passcode.equals("1234")){
                             Toast.makeText(signup.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                             Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                             startActivity(intent);
                         }else{
                             Toast.makeText(signup.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                         }
                     }
                     else{
                         Toast.makeText(signup.this, "User already exists! Please Login", Toast.LENGTH_SHORT).show();
                     }
                 }else{
                     Toast.makeText(signup.this, "Password not matching", Toast.LENGTH_SHORT).show();
                 }
             }

            }
        });
        _textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });
    }

}