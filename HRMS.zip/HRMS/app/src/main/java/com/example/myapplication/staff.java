package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class staff extends AppCompatActivity {
    RecyclerView recyclerView;
    FloatingActionButton fade;

    databass myDB;
    ArrayList<String> book_id, book_name, book_position, book_email, book_dob, book_quality;
    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff);

        recyclerView = findViewById(R.id.surf);
        fade = findViewById(R.id.fade);
        fade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(staff.this, staff2.class);
                startActivity(intent);
            }

        });
        myDB = new databass(staff.this);
        book_id = new ArrayList<>();
        book_name = new ArrayList<>();
        book_position = new ArrayList<>();
        book_email = new ArrayList<>();
        book_dob = new ArrayList<>();
        book_quality =  new ArrayList<>();

       storeDatainArrays();

       customAdapter = new CustomAdapter( staff.this, this, book_id, book_name, book_position, book_email, book_dob, book_quality);
       recyclerView.setAdapter(customAdapter);
       recyclerView.setLayoutManager(new LinearLayoutManager(staff.this));

    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            recreate();
        }
    }

    void  storeDatainArrays() {
        Cursor cursor = myDB.readAllData();
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
        }else {
            while (cursor.moveToNext()){
                book_id.add(cursor.getString(0));
                book_name.add(cursor.getString(1));
                book_position.add(cursor.getString(2));
                book_email.add(cursor.getString(3));
                book_dob.add(cursor.getString(4));
                book_quality.add(cursor.getString(5));
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.my_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.delete_all){
            Toast.makeText(this, "Delete", Toast.LENGTH_SHORT).show();
            databass myDB = new databass(this);
            myDB.deleteAllData();
            recreate();
        }else{
            Toast.makeText(this, "failed to Delete", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}