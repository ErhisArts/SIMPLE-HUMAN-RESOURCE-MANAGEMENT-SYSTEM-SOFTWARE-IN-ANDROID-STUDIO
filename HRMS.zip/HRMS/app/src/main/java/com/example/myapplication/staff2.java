package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class staff2 extends AppCompatActivity {

    EditText tb1, tb2, tb3, tb4,tb5;
    Button button1;
    FloatingActionButton floatingActionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff2);

        tb1 = findViewById(R.id.name);
        tb2 = findViewById(R.id.position);
        tb3 = findViewById(R.id.email);
        tb4 = findViewById(R.id.dob);
        tb5 = findViewById(R.id.quali);
       button1 = findViewById(R.id.button1);
        floatingActionButton = findViewById(R.id.floatingActionButton1);

        floatingActionButton.setOnClickListener(v->onBackPressed());

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databass myDB = new databass(staff2.this);
                myDB.addBook(tb1.getText().toString().trim(),
                        tb2.getText().toString().trim(),
                        tb3.getText().toString().trim(),
                        tb4.getText().toString().trim(),
                        tb5.getText().toString().trim());
                        recreate();
            }
        });
    }
}